package com.example.roomentityrelationshipdemo.entity;

public class MobileEntity {

    public String work;
    public String home;

    public MobileEntity(String work, String home) {
        this.work = work;
        this.home = home;
    }
}
